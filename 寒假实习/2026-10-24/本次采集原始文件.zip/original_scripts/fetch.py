import urllib.request,pathlib,sys,re
from html.parser import HTMLParser
class P(HTMLParser):
 def __init__(self):super().__init__();self.skip=0;self.out=[];self.links=[]
 def handle_starttag(self,t,a):
  if t in ('script','style'):self.skip+=1
  if t=='a':
   d=dict(a)
   if 'href' in d and any(k in d['href'] for k in ('intern/','job_detail','jobs/')):self.links.append(d['href'])
 def handle_endtag(self,t):
  if t in ('script','style'):self.skip=max(0,self.skip-1)
 def handle_data(self,s):
  if not self.skip and s.strip():self.out.append(s.strip())
def fetch(u,name):
 try:
  r=urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'Mozilla/5.0'}),timeout=30);s=r.read().decode('utf-8','replace');pathlib.Path('/workspace/scratch/recruiting/'+name+'.html').write_text(s);p=P();p.feed(s);txt='\n'.join(p.out)+'\nLINKS\n'+'\n'.join(dict.fromkeys(p.links));pathlib.Path('/workspace/scratch/recruiting/'+name+'.txt').write_text(txt);return txt
 except Exception as e:return str(e)
if __name__=='__main__':print(fetch(sys.argv[1],sys.argv[2]))
